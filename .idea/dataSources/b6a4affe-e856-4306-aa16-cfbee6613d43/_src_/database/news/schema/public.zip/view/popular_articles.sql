CREATE VIEW popular_articles AS SELECT "substring"(log.path, 10) AS log_slug,
    count(log.path) AS count
   FROM log
  WHERE (log.path ~~ '/article%'::text)
  GROUP BY log.path
  ORDER BY count(log.path) DESC;
