CREATE VIEW count_err AS SELECT to_char(log."time", 'Month DD, YYYY'::text) AS day,
    count(to_char(log."time", 'Month DD, YYYY'::text)) AS count
   FROM log
  WHERE (log.status <> '200 OK'::text)
  GROUP BY to_char(log."time", 'Month DD, YYYY'::text)
  ORDER BY to_char(log."time", 'Month DD, YYYY'::text);
