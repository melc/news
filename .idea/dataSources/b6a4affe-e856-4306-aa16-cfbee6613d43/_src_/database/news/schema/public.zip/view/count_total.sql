CREATE VIEW count_total AS SELECT to_char(log."time", 'Month DD, YYYY'::text) AS day,
    count(to_char(log."time", 'Month DD, YYYY'::text)) AS count
   FROM log
  GROUP BY to_char(log."time", 'Month DD, YYYY'::text)
  ORDER BY to_char(log."time", 'Month DD, YYYY'::text);
